If you're using royaloakap through Docker, your Redis `dump.rdb` will show up here.

If you're importing an existing database, please put your `dump.rdb` in here.