#!/bin/sh
ruby main.rb
